
## 2025-10-25T20:00:00.290157
```json
{
  "ts": "2025-10-25T20:00:00.290157",
  "new_signups": 6,
  "active_users": 191,
  "revenue_usd": 48.82,
  "referrals": 10,
  "plan_mix": {
    "basic": 60,
    "pro": 30,
    "enterprise": 10
  }
}
```

## 2025-10-26T20:00:00.888072
```json
{
  "ts": "2025-10-26T20:00:00.888072",
  "new_signups": 20,
  "active_users": 129,
  "revenue_usd": 58.85,
  "referrals": 7,
  "plan_mix": {
    "basic": 60,
    "pro": 30,
    "enterprise": 10
  }
}
```
