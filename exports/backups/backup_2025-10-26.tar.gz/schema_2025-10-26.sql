--
-- PostgreSQL database dump
--

-- Dumped from database version 16.9 (165f042)
-- Dumped by pg_dump version 16.9

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: feature_flags; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.feature_flags (
    name character varying(100) NOT NULL,
    enabled boolean DEFAULT true,
    metadata jsonb,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.feature_flags OWNER TO neondb_owner;

--
-- Name: offer_impressions; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.offer_impressions (
    user_id character varying(255) NOT NULL,
    offer_id integer NOT NULL,
    ts timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.offer_impressions OWNER TO neondb_owner;

--
-- Name: offer_redemptions; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.offer_redemptions (
    user_id character varying(255) NOT NULL,
    offer_id integer NOT NULL,
    ts timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    amount_cents integer
);


ALTER TABLE public.offer_redemptions OWNER TO neondb_owner;

--
-- Name: offers; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.offers (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    segment_id integer,
    rule_json jsonb,
    coupon_code character varying(50),
    discount_pct integer,
    expires_at timestamp without time zone,
    limit_total integer,
    redeemed integer DEFAULT 0,
    active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.offers OWNER TO neondb_owner;

--
-- Name: offers_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.offers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.offers_id_seq OWNER TO neondb_owner;

--
-- Name: offers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.offers_id_seq OWNED BY public.offers.id;


--
-- Name: segments; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.segments (
    id integer NOT NULL,
    label character varying(100) NOT NULL,
    rules_json jsonb,
    size integer DEFAULT 0,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.segments OWNER TO neondb_owner;

--
-- Name: segments_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.segments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.segments_id_seq OWNER TO neondb_owner;

--
-- Name: segments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.segments_id_seq OWNED BY public.segments.id;


--
-- Name: subscriptions; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.subscriptions (
    id integer NOT NULL,
    user_id character varying(255) NOT NULL,
    plan character varying(50) NOT NULL,
    status character varying(50) DEFAULT 'active'::character varying NOT NULL,
    current_period_end timestamp without time zone,
    retries integer DEFAULT 0,
    last_payment_intent character varying(255),
    stripe_subscription_id character varying(255),
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    stripe_customer_id character varying(255)
);


ALTER TABLE public.subscriptions OWNER TO neondb_owner;

--
-- Name: subscriptions_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.subscriptions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.subscriptions_id_seq OWNER TO neondb_owner;

--
-- Name: subscriptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.subscriptions_id_seq OWNED BY public.subscriptions.id;


--
-- Name: usage_events; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.usage_events (
    id integer NOT NULL,
    user_id character varying(255) NOT NULL,
    metric character varying(50) NOT NULL,
    qty numeric(10,4) NOT NULL,
    unit_price_cents integer,
    ts timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.usage_events OWNER TO neondb_owner;

--
-- Name: usage_events_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.usage_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.usage_events_id_seq OWNER TO neondb_owner;

--
-- Name: usage_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.usage_events_id_seq OWNED BY public.usage_events.id;


--
-- Name: usage_invoices; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.usage_invoices (
    id integer NOT NULL,
    user_id character varying(255) NOT NULL,
    period_start timestamp without time zone NOT NULL,
    period_end timestamp without time zone NOT NULL,
    subtotal_cents integer NOT NULL,
    credits_cents integer DEFAULT 0,
    total_cents integer NOT NULL,
    stripe_invoice_id character varying(255),
    status character varying(50) DEFAULT 'draft'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.usage_invoices OWNER TO neondb_owner;

--
-- Name: usage_invoices_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.usage_invoices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.usage_invoices_id_seq OWNER TO neondb_owner;

--
-- Name: usage_invoices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.usage_invoices_id_seq OWNED BY public.usage_invoices.id;


--
-- Name: user_segments; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.user_segments (
    user_id character varying(255) NOT NULL,
    segment_id integer NOT NULL,
    assigned_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.user_segments OWNER TO neondb_owner;

--
-- Name: wallet_transactions; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.wallet_transactions (
    id integer NOT NULL,
    user_id character varying(255) NOT NULL,
    type character varying(20) NOT NULL,
    amount_cents integer NOT NULL,
    ref character varying(255),
    reason text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.wallet_transactions OWNER TO neondb_owner;

--
-- Name: wallet_transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.wallet_transactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.wallet_transactions_id_seq OWNER TO neondb_owner;

--
-- Name: wallet_transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.wallet_transactions_id_seq OWNED BY public.wallet_transactions.id;


--
-- Name: wallets; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.wallets (
    user_id character varying(255) NOT NULL,
    balance_cents integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.wallets OWNER TO neondb_owner;

--
-- Name: wh_automation_log; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.wh_automation_log (
    id character varying(255) NOT NULL,
    task text,
    status character varying(50),
    message text,
    details text,
    "timestamp" timestamp without time zone,
    commit text,
    created_time timestamp without time zone,
    synced_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.wh_automation_log OWNER TO neondb_owner;

--
-- Name: wh_automation_queue; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.wh_automation_queue (
    id character varying(255) NOT NULL,
    task_name text,
    description text,
    trigger boolean,
    status character varying(50),
    task_type character varying(100),
    qa_target numeric,
    created_time timestamp without time zone,
    last_edited_time timestamp without time zone,
    synced_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.wh_automation_queue OWNER TO neondb_owner;

--
-- Name: wh_clients; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.wh_clients (
    id character varying(255) NOT NULL,
    client_name text,
    email text,
    rate_usd_per_min numeric,
    active boolean,
    notes text,
    created_time timestamp without time zone,
    last_edited_time timestamp without time zone,
    synced_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.wh_clients OWNER TO neondb_owner;

--
-- Name: wh_finance; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.wh_finance (
    id character varying(255) NOT NULL,
    transaction_id text,
    date timestamp without time zone,
    type character varying(50),
    amount numeric,
    currency character varying(10),
    client text,
    job_id text,
    margin_pct numeric,
    reconciled boolean,
    stripe_payment_id text,
    notes text,
    created_time timestamp without time zone,
    synced_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.wh_finance OWNER TO neondb_owner;

--
-- Name: wh_forecast; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.wh_forecast (
    id character varying(255) NOT NULL,
    date_title text,
    forecast_type character varying(50),
    predicted_value numeric,
    actual_value numeric,
    accuracy_pct numeric,
    confidence character varying(50),
    model_used text,
    notes text,
    created_time timestamp without time zone,
    synced_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.wh_forecast OWNER TO neondb_owner;

--
-- Name: wh_governance; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.wh_governance (
    id character varying(255) NOT NULL,
    decision text,
    date timestamp without time zone,
    type character varying(50),
    status character varying(50),
    decision_maker text,
    impact character varying(50),
    rationale text,
    outcomes text,
    related_risks text,
    created_time timestamp without time zone,
    synced_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.wh_governance OWNER TO neondb_owner;

--
-- Name: wh_growth_metrics; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.wh_growth_metrics (
    id character varying(255) NOT NULL,
    date_title text,
    metric character varying(50),
    value numeric,
    source character varying(50),
    campaign text,
    cost numeric,
    roi_pct numeric,
    created_time timestamp without time zone,
    synced_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.wh_growth_metrics OWNER TO neondb_owner;

--
-- Name: wh_job_log; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.wh_job_log (
    id character varying(255) NOT NULL,
    job_name text,
    qa_score numeric,
    cost numeric,
    status character varying(50),
    notes text,
    "timestamp" timestamp without time zone,
    commit text,
    task_type character varying(100),
    duration_ms integer,
    tokens_in integer,
    tokens_out integer,
    payment_link text,
    payment_status character varying(50),
    client_rate_usd_per_min numeric,
    gross_usd numeric,
    profit_usd numeric,
    margin_pct numeric,
    created_time timestamp without time zone,
    synced_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.wh_job_log OWNER TO neondb_owner;

--
-- Name: wh_job_node_logs; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.wh_job_node_logs (
    id integer NOT NULL,
    job_id character varying(255),
    node_id character varying(255) NOT NULL,
    node_type character varying(100),
    status character varying(50) NOT NULL,
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    duration_ms integer,
    input_data jsonb,
    output_data jsonb,
    error_message text,
    retry_count integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.wh_job_node_logs OWNER TO neondb_owner;

--
-- Name: wh_job_node_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.wh_job_node_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.wh_job_node_logs_id_seq OWNER TO neondb_owner;

--
-- Name: wh_job_node_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.wh_job_node_logs_id_seq OWNED BY public.wh_job_node_logs.id;


--
-- Name: wh_jobs; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.wh_jobs (
    id character varying(255) NOT NULL,
    workflow_id character varying(255),
    workflow_version integer,
    status character varying(50) DEFAULT 'queued'::character varying NOT NULL,
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    duration_ms integer,
    triggered_by character varying(255),
    trigger_type character varying(50),
    input_data jsonb,
    output_data jsonb,
    error_message text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.wh_jobs OWNER TO neondb_owner;

--
-- Name: wh_ops_monitor; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.wh_ops_monitor (
    id character varying(255) NOT NULL,
    timestamp_title text,
    component character varying(100),
    status character varying(50),
    metric text,
    value numeric,
    threshold numeric,
    alert_sent boolean,
    resolution text,
    auto_fixed boolean,
    created_time timestamp without time zone,
    synced_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.wh_ops_monitor OWNER TO neondb_owner;

--
-- Name: wh_partners; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.wh_partners (
    id character varying(255) NOT NULL,
    partner_name text,
    api_key_hash text,
    tier character varying(50),
    quota_monthly integer,
    usage_current integer,
    revenue_share_pct numeric,
    contact_email text,
    active boolean,
    created_date timestamp without time zone,
    created_time timestamp without time zone,
    synced_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.wh_partners OWNER TO neondb_owner;

--
-- Name: wh_permissions; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.wh_permissions (
    id integer NOT NULL,
    user_id character varying(255) NOT NULL,
    resource_type character varying(100) NOT NULL,
    resource_id character varying(255),
    role character varying(50) NOT NULL,
    granted_at timestamp without time zone DEFAULT now(),
    granted_by character varying(255)
);


ALTER TABLE public.wh_permissions OWNER TO neondb_owner;

--
-- Name: wh_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.wh_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.wh_permissions_id_seq OWNER TO neondb_owner;

--
-- Name: wh_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.wh_permissions_id_seq OWNED BY public.wh_permissions.id;


--
-- Name: wh_referrals; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.wh_referrals (
    id character varying(255) NOT NULL,
    referral_code text,
    referrer text,
    referred_customer text,
    status character varying(50),
    credit_amount numeric,
    applied boolean,
    created_date timestamp without time zone,
    created_time timestamp without time zone,
    synced_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.wh_referrals OWNER TO neondb_owner;

--
-- Name: wh_region_compliance; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.wh_region_compliance (
    id character varying(255) NOT NULL,
    region text,
    country_code character varying(10),
    data_retention_days integer,
    currency character varying(10),
    language character varying(10),
    gdpr_required boolean,
    ccpa_required boolean,
    created_time timestamp without time zone,
    synced_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.wh_region_compliance OWNER TO neondb_owner;

--
-- Name: wh_secrets; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.wh_secrets (
    id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    encrypted_value text NOT NULL,
    owner_id character varying(255),
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    last_accessed_at timestamp without time zone
);


ALTER TABLE public.wh_secrets OWNER TO neondb_owner;

--
-- Name: wh_sync_metadata; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.wh_sync_metadata (
    id integer NOT NULL,
    table_name character varying(100),
    sync_started_at timestamp without time zone,
    sync_completed_at timestamp without time zone,
    rows_synced integer,
    status character varying(50),
    error_message text
);


ALTER TABLE public.wh_sync_metadata OWNER TO neondb_owner;

--
-- Name: wh_sync_metadata_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.wh_sync_metadata_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.wh_sync_metadata_id_seq OWNER TO neondb_owner;

--
-- Name: wh_sync_metadata_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.wh_sync_metadata_id_seq OWNED BY public.wh_sync_metadata.id;


--
-- Name: wh_workflow_versions; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.wh_workflow_versions (
    id integer NOT NULL,
    workflow_id character varying(255),
    version integer NOT NULL,
    definition jsonb NOT NULL,
    published_at timestamp without time zone DEFAULT now(),
    published_by character varying(255),
    is_current boolean DEFAULT false
);


ALTER TABLE public.wh_workflow_versions OWNER TO neondb_owner;

--
-- Name: wh_workflow_versions_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.wh_workflow_versions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.wh_workflow_versions_id_seq OWNER TO neondb_owner;

--
-- Name: wh_workflow_versions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.wh_workflow_versions_id_seq OWNED BY public.wh_workflow_versions.id;


--
-- Name: wh_workflows; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.wh_workflows (
    id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    owner_id character varying(255),
    is_active boolean DEFAULT true,
    definition jsonb NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.wh_workflows OWNER TO neondb_owner;

--
-- Name: offers id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.offers ALTER COLUMN id SET DEFAULT nextval('public.offers_id_seq'::regclass);


--
-- Name: segments id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.segments ALTER COLUMN id SET DEFAULT nextval('public.segments_id_seq'::regclass);


--
-- Name: subscriptions id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.subscriptions ALTER COLUMN id SET DEFAULT nextval('public.subscriptions_id_seq'::regclass);


--
-- Name: usage_events id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.usage_events ALTER COLUMN id SET DEFAULT nextval('public.usage_events_id_seq'::regclass);


--
-- Name: usage_invoices id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.usage_invoices ALTER COLUMN id SET DEFAULT nextval('public.usage_invoices_id_seq'::regclass);


--
-- Name: wallet_transactions id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.wallet_transactions ALTER COLUMN id SET DEFAULT nextval('public.wallet_transactions_id_seq'::regclass);


--
-- Name: wh_job_node_logs id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.wh_job_node_logs ALTER COLUMN id SET DEFAULT nextval('public.wh_job_node_logs_id_seq'::regclass);


--
-- Name: wh_permissions id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.wh_permissions ALTER COLUMN id SET DEFAULT nextval('public.wh_permissions_id_seq'::regclass);


--
-- Name: wh_sync_metadata id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.wh_sync_metadata ALTER COLUMN id SET DEFAULT nextval('public.wh_sync_metadata_id_seq'::regclass);


--
-- Name: wh_workflow_versions id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.wh_workflow_versions ALTER COLUMN id SET DEFAULT nextval('public.wh_workflow_versions_id_seq'::regclass);


--
-- Name: feature_flags feature_flags_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.feature_flags
    ADD CONSTRAINT feature_flags_pkey PRIMARY KEY (name);


--
-- Name: offer_redemptions offer_redemptions_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.offer_redemptions
    ADD CONSTRAINT offer_redemptions_pkey PRIMARY KEY (user_id, offer_id);


--
-- Name: offers offers_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.offers
    ADD CONSTRAINT offers_pkey PRIMARY KEY (id);


--
-- Name: segments segments_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.segments
    ADD CONSTRAINT segments_pkey PRIMARY KEY (id);


--
-- Name: subscriptions subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_pkey PRIMARY KEY (id);


--
-- Name: usage_events usage_events_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.usage_events
    ADD CONSTRAINT usage_events_pkey PRIMARY KEY (id);


--
-- Name: usage_invoices usage_invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.usage_invoices
    ADD CONSTRAINT usage_invoices_pkey PRIMARY KEY (id);


--
-- Name: user_segments user_segments_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.user_segments
    ADD CONSTRAINT user_segments_pkey PRIMARY KEY (user_id, segment_id);


--
-- Name: wallet_transactions wallet_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.wallet_transactions
    ADD CONSTRAINT wallet_transactions_pkey PRIMARY KEY (id);


--
-- Name: wallets wallets_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.wallets
    ADD CONSTRAINT wallets_pkey PRIMARY KEY (user_id);


--
-- Name: wh_automation_log wh_automation_log_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.wh_automation_log
    ADD CONSTRAINT wh_automation_log_pkey PRIMARY KEY (id);


--
-- Name: wh_automation_queue wh_automation_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.wh_automation_queue
    ADD CONSTRAINT wh_automation_queue_pkey PRIMARY KEY (id);


--
-- Name: wh_clients wh_clients_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.wh_clients
    ADD CONSTRAINT wh_clients_pkey PRIMARY KEY (id);


--
-- Name: wh_finance wh_finance_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.wh_finance
    ADD CONSTRAINT wh_finance_pkey PRIMARY KEY (id);


--
-- Name: wh_forecast wh_forecast_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.wh_forecast
    ADD CONSTRAINT wh_forecast_pkey PRIMARY KEY (id);


--
-- Name: wh_governance wh_governance_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.wh_governance
    ADD CONSTRAINT wh_governance_pkey PRIMARY KEY (id);


--
-- Name: wh_growth_metrics wh_growth_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.wh_growth_metrics
    ADD CONSTRAINT wh_growth_metrics_pkey PRIMARY KEY (id);


--
-- Name: wh_job_log wh_job_log_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.wh_job_log
    ADD CONSTRAINT wh_job_log_pkey PRIMARY KEY (id);


--
-- Name: wh_job_node_logs wh_job_node_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.wh_job_node_logs
    ADD CONSTRAINT wh_job_node_logs_pkey PRIMARY KEY (id);


--
-- Name: wh_jobs wh_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.wh_jobs
    ADD CONSTRAINT wh_jobs_pkey PRIMARY KEY (id);


--
-- Name: wh_ops_monitor wh_ops_monitor_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.wh_ops_monitor
    ADD CONSTRAINT wh_ops_monitor_pkey PRIMARY KEY (id);


--
-- Name: wh_partners wh_partners_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.wh_partners
    ADD CONSTRAINT wh_partners_pkey PRIMARY KEY (id);


--
-- Name: wh_permissions wh_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.wh_permissions
    ADD CONSTRAINT wh_permissions_pkey PRIMARY KEY (id);


--
-- Name: wh_permissions wh_permissions_user_id_resource_type_resource_id_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.wh_permissions
    ADD CONSTRAINT wh_permissions_user_id_resource_type_resource_id_key UNIQUE (user_id, resource_type, resource_id);


--
-- Name: wh_referrals wh_referrals_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.wh_referrals
    ADD CONSTRAINT wh_referrals_pkey PRIMARY KEY (id);


--
-- Name: wh_region_compliance wh_region_compliance_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.wh_region_compliance
    ADD CONSTRAINT wh_region_compliance_pkey PRIMARY KEY (id);


--
-- Name: wh_secrets wh_secrets_name_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.wh_secrets
    ADD CONSTRAINT wh_secrets_name_key UNIQUE (name);


--
-- Name: wh_secrets wh_secrets_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.wh_secrets
    ADD CONSTRAINT wh_secrets_pkey PRIMARY KEY (id);


--
-- Name: wh_sync_metadata wh_sync_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.wh_sync_metadata
    ADD CONSTRAINT wh_sync_metadata_pkey PRIMARY KEY (id);


--
-- Name: wh_workflow_versions wh_workflow_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.wh_workflow_versions
    ADD CONSTRAINT wh_workflow_versions_pkey PRIMARY KEY (id);


--
-- Name: wh_workflow_versions wh_workflow_versions_workflow_id_version_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.wh_workflow_versions
    ADD CONSTRAINT wh_workflow_versions_workflow_id_version_key UNIQUE (workflow_id, version);


--
-- Name: wh_workflows wh_workflows_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.wh_workflows
    ADD CONSTRAINT wh_workflows_pkey PRIMARY KEY (id);


--
-- Name: idx_job_logs_job; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_job_logs_job ON public.wh_job_node_logs USING btree (job_id);


--
-- Name: idx_jobs_created; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_jobs_created ON public.wh_jobs USING btree (created_at DESC);


--
-- Name: idx_jobs_status; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_jobs_status ON public.wh_jobs USING btree (status);


--
-- Name: idx_jobs_workflow; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_jobs_workflow ON public.wh_jobs USING btree (workflow_id);


--
-- Name: idx_offer_impr_user; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_offer_impr_user ON public.offer_impressions USING btree (user_id, ts DESC);


--
-- Name: idx_permissions_resource; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_permissions_resource ON public.wh_permissions USING btree (resource_type, resource_id);


--
-- Name: idx_permissions_user; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_permissions_user ON public.wh_permissions USING btree (user_id);


--
-- Name: idx_subscriptions_period_end; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_subscriptions_period_end ON public.subscriptions USING btree (current_period_end);


--
-- Name: idx_subscriptions_stripe_customer; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_subscriptions_stripe_customer ON public.subscriptions USING btree (stripe_customer_id);


--
-- Name: idx_subscriptions_user_status; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_subscriptions_user_status ON public.subscriptions USING btree (user_id, status);


--
-- Name: idx_usage_invoices_user; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_usage_invoices_user ON public.usage_invoices USING btree (user_id, period_start DESC);


--
-- Name: idx_usage_metric_ts; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_usage_metric_ts ON public.usage_events USING btree (metric, ts);


--
-- Name: idx_usage_user_ts; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_usage_user_ts ON public.usage_events USING btree (user_id, ts DESC);


--
-- Name: idx_wallet_txn_user; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_wallet_txn_user ON public.wallet_transactions USING btree (user_id, created_at DESC);


--
-- Name: idx_workflow_versions_current; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_workflow_versions_current ON public.wh_workflow_versions USING btree (is_current);


--
-- Name: idx_workflow_versions_workflow; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_workflow_versions_workflow ON public.wh_workflow_versions USING btree (workflow_id);


--
-- Name: idx_workflows_active; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_workflows_active ON public.wh_workflows USING btree (is_active);


--
-- Name: idx_workflows_owner; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_workflows_owner ON public.wh_workflows USING btree (owner_id);


--
-- Name: offer_impressions offer_impressions_offer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.offer_impressions
    ADD CONSTRAINT offer_impressions_offer_id_fkey FOREIGN KEY (offer_id) REFERENCES public.offers(id);


--
-- Name: offer_redemptions offer_redemptions_offer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.offer_redemptions
    ADD CONSTRAINT offer_redemptions_offer_id_fkey FOREIGN KEY (offer_id) REFERENCES public.offers(id);


--
-- Name: offers offers_segment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.offers
    ADD CONSTRAINT offers_segment_id_fkey FOREIGN KEY (segment_id) REFERENCES public.segments(id);


--
-- Name: user_segments user_segments_segment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.user_segments
    ADD CONSTRAINT user_segments_segment_id_fkey FOREIGN KEY (segment_id) REFERENCES public.segments(id);


--
-- Name: wh_job_node_logs wh_job_node_logs_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.wh_job_node_logs
    ADD CONSTRAINT wh_job_node_logs_job_id_fkey FOREIGN KEY (job_id) REFERENCES public.wh_jobs(id) ON DELETE CASCADE;


--
-- Name: wh_jobs wh_jobs_workflow_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.wh_jobs
    ADD CONSTRAINT wh_jobs_workflow_id_fkey FOREIGN KEY (workflow_id) REFERENCES public.wh_workflows(id) ON DELETE CASCADE;


--
-- Name: wh_workflow_versions wh_workflow_versions_workflow_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.wh_workflow_versions
    ADD CONSTRAINT wh_workflow_versions_workflow_id_fkey FOREIGN KEY (workflow_id) REFERENCES public.wh_workflows(id) ON DELETE CASCADE;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: cloud_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE cloud_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO neon_superuser WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: cloud_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE cloud_admin IN SCHEMA public GRANT ALL ON TABLES TO neon_superuser WITH GRANT OPTION;


--
-- PostgreSQL database dump complete
--

